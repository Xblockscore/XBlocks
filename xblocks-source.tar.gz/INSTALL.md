Building XBlocks
=============

See doc/build-*.md for instructions on building the various
elements of the XBlocks Core reference implementation of XBlocks.
